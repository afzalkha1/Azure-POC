﻿using System.Text.Json;
using Azure.Messaging.ServiceBus;
using AzurePoc.Models;
using Microsoft.AspNetCore.Mvc;

namespace AzurePoc.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class EmployeeController : ControllerBase
    {
        // Fields to store configuration values for Service Bus and Azure Blob Storage
        private readonly string _serviceBusConnectionString;
        private readonly string _queueName;
        private readonly string _storageConnectionString;
        private readonly string _containerName;

        /// <summary>
        /// Constructor to initialize the controller with configuration values.
        /// </summary>
        /// <param name="configuration">The application configuration containing required keys and values.</param>
        public EmployeeController(IConfiguration configuration)
        {
            // Assign configuration values for Azure Service Bus and Azure Blob Storage
            _serviceBusConnectionString = configuration["AzureServiceBus:ConnectionString"];
            _queueName = configuration["AzureServiceBus:QueueName"];
            
        }

        /// <summary>
        /// API endpoint to send an employee message to the Azure Service Bus queue.
        /// </summary>
        /// <param name="employee">The Employee object received in the request body.</param>
        /// <returns>Returns a success response if the message is sent successfully, otherwise an error response.</returns>
        [HttpPost]
        public async Task<IActionResult> SendMessage([FromBody] Employee employee)
        {
            try
            {
                // Create a ServiceBusClient to connect to the Azure Service Bus
                var client = new ServiceBusClient(_serviceBusConnectionString);


                var sender = client.CreateSender(_queueName);


                string messageBody = JsonSerializer.Serialize(employee);


                var message = new ServiceBusMessage(messageBody);

                await sender.SendMessageAsync(message);

                await sender.DisposeAsync();
                await client.DisposeAsync();

                // Return an HTTP 200 OK response indicating success
                return Ok("Message sent successfully.");
            }
            catch (Exception ex)
            {
                // If any error occurs, return an HTTP 500 Internal Server Error response with the error details
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
    }
}
