using Azure.Messaging.ServiceBus;
using Azure.Storage.Blobs;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace AzureFunction
{
    public class Function1
    {
        private readonly ILogger<Function1> _logger;
        private readonly string _storageConnectionString;
        private readonly string _containerName;

        public Function1(ILogger<Function1> logger,IConfiguration configuration)
        {
            _logger = logger;
            _storageConnectionString = configuration["AzureStorage:ConnectionString"];
            _containerName = configuration["AzureStorage:ContainerName"];
        }

        [Function(nameof(Function1))]
        public async Task Run(
            [ServiceBusTrigger("order-queue", Connection = "ServiceBusConnectionString")]
            ServiceBusReceivedMessage message,
            ServiceBusMessageActions messageActions)
        {
            _logger.LogInformation("Message ID: {id}", message.MessageId);
            _logger.LogInformation("Message Body: {body}", message.Body);
            _logger.LogInformation("Message Content-Type: {contentType}", message.ContentType);

            try
            {
                // Save message to Azure Blob Storage
                var blobServiceClient = new BlobServiceClient(_storageConnectionString);
                var containerClient = blobServiceClient.GetBlobContainerClient(_containerName);
                await containerClient.CreateIfNotExistsAsync();

                string blobName = $"message-{Guid.NewGuid()}.json";
                var blobClient = containerClient.GetBlobClient(blobName);

                await blobClient.UploadAsync(BinaryData.FromString(message.Body.ToString()));

                _logger.LogInformation($"Message saved to blob: {blobName}");

                // Complete the message
                await messageActions.CompleteMessageAsync(message);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error saving message to Blob Storage: {ex.Message}");
            }
        }
    }
}
